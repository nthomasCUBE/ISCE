<?php

namespace integration\PhpSpec\Loader\examples;

use PhpSpec\ObjectBehavior;

class ExampleSpec extends ObjectBehavior
{
    function it_requires_a_stdclass(\stdClass $class)
    {

    }
}
