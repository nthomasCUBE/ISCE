<?php

namespace Noodlehaus\Exception;

use Exception;

class EmptyDirectoryException extends Exception
{
}
