<?php

namespace Noodlehaus\Exception;

use Exception;

class FileNotFoundException extends Exception
{
}
