<?php

namespace Noodlehaus\Exception;

use Exception;

class UnsupportedFormatException extends Exception
{
}
